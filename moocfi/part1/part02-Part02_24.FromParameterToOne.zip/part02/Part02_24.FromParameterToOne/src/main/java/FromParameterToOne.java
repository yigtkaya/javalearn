

public class FromParameterToOne {

    public static void main(String[] args) {


    }

}
