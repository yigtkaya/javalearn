
import java.util.Scanner;

public class NumberUno {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

    }

}
