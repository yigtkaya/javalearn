

public class FromOneToParameter {

    public static void main(String[] args) {

    }

}
