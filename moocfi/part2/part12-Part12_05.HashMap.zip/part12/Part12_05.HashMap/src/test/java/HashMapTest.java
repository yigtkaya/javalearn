
import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.Test;

@Points("12-05.1 12-05.2 12-05.3")
public class HashMapTest {

    @Test
    public void noTests() {

    }

}
