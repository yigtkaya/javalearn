
import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.Test;

@Points("12-01")
public class HideoutTest {

    @Test
    public void noTests() {

    }
}
