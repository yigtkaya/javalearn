

public class MainProgram {

    public static void main(String[] args) {
        // test your method here

    }

    // Implement here a method returnSize, which takes a Map-object as a parameter 
    // and returns the size of the map object
}
