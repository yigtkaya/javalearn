
import java.util.HashMap;

public class Program {

    public static void main(String[] args) {
        // Test your program here!
    }

}
